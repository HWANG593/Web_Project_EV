from django.apps import AppConfig


class EvappConfig(AppConfig):
    name = 'EVapp'
